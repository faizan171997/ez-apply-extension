chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (message.type == "get_response") {
        navigator.clipboard.writeText(message.data.choices[0].text.trim()).then(() => {
            alert('Text copied!');
        }, () => {
            alert('Oops! That failed :(');
        });
    } else if (message.type == "paraphrase") {
        document.activeElement.value = message.data.choices[0].text.trim();
    }
});

document.addEventListener('keypress', e => {
    if (e.shiftKey && e.code == 'KeyZ') {
        alert('Hey!');
    }
});

/**
 * document.querySelector('[data-automation-id="formField-skillsPrompt"]').getElementsByTagName('input')[0].click();
 * document.querySelector('[data-automation-id="formField-skillsPrompt"]').getElementsByTagName('input')[0].value = "kafka";
 */